from __future__ import annotations

import bpy

from ..constants import MODE_ANIMATED, PROP_FRAME, PROP_LABEL
from ..core.parser import scan_scene_controllers


def get_controller_pbone(entry):
    rig_obj = bpy.data.objects.get(entry.armature_name)
    if rig_obj is None or rig_obj.type != 'ARMATURE' or rig_obj.pose is None:
        return None
    return rig_obj.pose.bones.get(entry.bone_name)


def draw_create_section(layout, context, settings) -> None:
    col = layout.column(align=True)
    col.prop(settings, "target_material", text="Material")
    col.prop(settings, "create_mode", text="Mode")
    col.prop(settings, "default_label", text="Beauty Name")

    col.separator()

    col.operator("sticksy.create_setup", text="Create", icon='ADD')


def draw_controller_row(layout, entry) -> None:
    pbone = get_controller_pbone(entry)

    box = layout.box()

    if pbone is None:
        row = box.row()
        row.label(text=f"Missing controller: {entry.bone_name}", icon='ERROR')
        return

    top = box.row(align=True)
    top.prop(pbone, f'["{PROP_LABEL}"]', text="")

    if entry.mode == MODE_ANIMATED:
        top.prop(pbone, f'["{PROP_FRAME}"]', text="Frame")

    row = box.row(align=True)
    op = row.operator("sticksy.new_layer", text="New Layer", icon='ADD')
    op.armature_name = entry.armature_name
    op.bone_name = entry.bone_name


def draw_manager_section(layout, context) -> None:
    entries = scan_scene_controllers(context.scene)

    if not entries:
        layout.label(text="No Sticksy controllers found", icon='INFO')
        return

    col = layout.column(align=True)
    for entry in entries:
        draw_controller_row(col, entry)


class STKSY_PT_create(bpy.types.Panel):
    bl_label = "Create"
    bl_idname = "STKSY_PT_create"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sticksy"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.sticksy
        draw_create_section(layout, context, settings)


class STKSY_PT_manager(bpy.types.Panel):
    bl_label = "Manager"
    bl_idname = "STKSY_PT_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Sticksy"

    def draw(self, context):
        layout = self.layout
        draw_manager_section(layout, context)