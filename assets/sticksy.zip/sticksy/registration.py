import bpy
from bpy.props import PointerProperty

from .props import STKSY_PG_scene_settings
from .ops.create_setup import STKSY_OT_create_setup
from .ops.new_layer import STKSY_OT_new_layer
from .ui.panels import STKSY_PT_create, STKSY_PT_manager


CLASSES = (
    STKSY_PG_scene_settings,
    STKSY_OT_create_setup,
    STKSY_OT_new_layer,
    STKSY_PT_create,
    STKSY_PT_manager,
)


def register_classes():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister_classes():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


def register():
    register_classes()
    bpy.types.Scene.sticksy = PointerProperty(type=STKSY_PG_scene_settings)


def unregister():
    if hasattr(bpy.types.Scene, "sticksy"):
        del bpy.types.Scene.sticksy
    unregister_classes()
