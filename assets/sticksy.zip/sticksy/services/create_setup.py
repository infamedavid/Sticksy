from __future__ import annotations

from ..core.bones import (
    configure_frame_property_ui,
    force_pose_bone_refresh,
    init_controller_properties,
)
from ..core.collections import ensure_system_collection
from ..core.custom_shapes import assign_texture_shape, ensure_texture_shape
from ..core.drivers import add_offset_driver
from ..core.empties import create_mapping_empty
from ..core.images import count_frames, load_image_sequence, load_single_image
from ..core.naming import (
    make_bone_name,
    make_default_label,
    make_empty_name,
    next_controller_index,
)
from ..core.nodes import create_projection_setup
from ..core.rig import (
    create_controller_bone,
    ensure_system_rig,
    get_pose_bone,
    parent_object_to_bone,
)
from ..core.validation import validate_create_request
from ..constants import MODE_ANIMATED


def create_setup(context, material, mode: str, filepaths: list[str], label: str | None = None) -> dict:
    ok, message = validate_create_request(material, mode, filepaths)
    if not ok:
        return {"ok": False, "message": message}

    controller = build_controller_system(
        context=context,
        material=material,
        mode=mode,
        label=label,
    )
    if not controller.get("ok"):
        return controller

    layer_result = create_first_texture_layer(
        context=context,
        material=material,
        empty_obj=controller["empty_obj"],
        rig_obj=controller["rig_obj"],
        bone_name=controller["bone_name"],
        mode=mode,
        filepaths=filepaths,
    )
    if not layer_result.get("ok"):
        return layer_result

    return {
        "ok": True,
        "message": (
            f"Sticksy setup created: {controller['bone_name']} / "
            f"{controller['empty_name']} / {layer_result['image_name']}"
        ),
        **controller,
        **layer_result,
    }


def build_controller_system(context, material, mode: str, label: str | None = None) -> dict:
    system_collection = ensure_system_collection(context)
    rig_obj = ensure_system_rig(context, system_collection)

    index = next_controller_index(rig_obj)
    bone_name = make_bone_name(index)
    empty_name = make_empty_name(index)
    beauty_label = (label or "").strip() or make_default_label(mode, index)
    world_location = context.scene.cursor.location.copy()

    bone_name = create_controller_bone(
        context=context,
        rig_obj=rig_obj,
        world_location=world_location,
        bone_name=bone_name,
    )

    pbone = get_pose_bone(rig_obj, bone_name)
    if pbone is None:
        return {"ok": False, "message": f"Failed to resolve new pose bone: {bone_name}"}

    empty_obj = create_mapping_empty(
        context=context,
        name=empty_name,
        world_location=world_location,
        collection=system_collection,
    )
    parent_object_to_bone(empty_obj, rig_obj, bone_name)

    init_controller_properties(
        pbone=pbone,
        label=beauty_label,
        mode=mode,
        material_name=material.name,
        empty_name=empty_obj.name,
    )

    context.view_layer.update()

    pbone = get_pose_bone(rig_obj, bone_name)
    if pbone is None:
        return {"ok": False, "message": f"Failed to re-resolve pose bone after update: {bone_name}"}

    force_pose_bone_refresh(context, rig_obj, bone_name)

    context.view_layer.update()

    pbone = get_pose_bone(rig_obj, bone_name)
    if pbone is None:
        return {"ok": False, "message": f"Failed to re-resolve pose bone after forced refresh: {bone_name}"}

    shape_obj = ensure_texture_shape(system_collection)
    assign_texture_shape(pbone, shape_obj)

    context.view_layer.update()

    return {
        "ok": True,
        "index": index,
        "rig_obj": rig_obj,
        "pbone": pbone,
        "bone_name": bone_name,
        "empty_obj": empty_obj,
        "empty_name": empty_obj.name,
        "label": beauty_label,
    }


def create_first_texture_layer(
    context,
    material,
    empty_obj,
    rig_obj,
    bone_name: str,
    mode: str,
    filepaths: list[str],
) -> dict:
    image = load_image_sequence(filepaths) if mode == MODE_ANIMATED else load_single_image(filepaths[0])
    if image is None:
        return {
            "ok": False,
            "message": "Failed to load selected image(s)",
        }

    node_result = create_projection_setup(
        material=material,
        empty_obj=empty_obj,
        image=image,
        mode=mode,
        filepaths=filepaths,
    )
    tex_node = node_result.get("image_texture")
    if tex_node is None:
        return {
            "ok": False,
            "message": "Failed to create Sticksy texture nodes",
        }

    if mode == MODE_ANIMATED:
        frame_count = count_frames(filepaths)
        pbone = get_pose_bone(rig_obj, bone_name)
        if pbone is not None:
            configure_frame_property_ui(pbone, max_value=max(0, frame_count - 1))
        context.view_layer.update()
        add_offset_driver(tex_node, rig_obj, bone_name)
        context.view_layer.update()

    return {
        "ok": True,
        "image": image,
        "image_name": image.name,
        **node_result,
    }