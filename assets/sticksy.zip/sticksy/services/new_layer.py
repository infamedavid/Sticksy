import bpy

from ..core.bones import get_empty_name, get_material_name, get_mode
from ..core.drivers import add_offset_driver
from ..core.empties import get_empty_by_name
from ..core.images import load_image_sequence, load_single_image
from ..core.materials import get_material_by_name
from ..core.nodes import create_projection_setup
from ..core.rig import get_pose_bone
from ..core.validation import validate_new_layer_request
from ..constants import MODE_ANIMATED


def create_new_layer(context, armature_name: str, bone_name: str, filepaths: list[str]) -> dict:
    controller = resolve_controller_data(armature_name, bone_name)
    if not controller.get("ok"):
        return controller

    ok, message = validate_new_layer_request(
        controller["pbone"],
        controller["material"],
        controller["empty"],
        filepaths=filepaths,
        mode=controller["mode"],
    )
    if not ok:
        return {"ok": False, "message": message}

    return build_additional_texture_layer(
        context=context,
        material=controller["material"],
        empty_obj=controller["empty"],
        mode=controller["mode"],
        rig_obj=controller["rig_obj"],
        bone_name=bone_name,
        filepaths=filepaths,
    )


def resolve_controller_data(armature_name: str, bone_name: str) -> dict:
    rig_obj = bpy.data.objects.get(armature_name)
    if rig_obj is None or rig_obj.type != 'ARMATURE':
        return {"ok": False, "message": f"Armature not found: {armature_name}"}

    pbone = get_pose_bone(rig_obj, bone_name)
    if pbone is None:
        return {"ok": False, "message": f"Bone not found: {bone_name}"}

    material = get_material_by_name(get_material_name(pbone))
    empty_obj = get_empty_by_name(get_empty_name(pbone))
    mode = get_mode(pbone)

    return {
        "ok": True,
        "rig_obj": rig_obj,
        "pbone": pbone,
        "material": material,
        "empty": empty_obj,
        "mode": mode,
    }


def build_additional_texture_layer(
    context,
    material,
    empty_obj,
    mode: str,
    rig_obj,
    bone_name: str,
    filepaths: list[str],
) -> dict:
    image = load_image_sequence(filepaths) if mode == MODE_ANIMATED else load_single_image(filepaths[0])
    if image is None:
        return {"ok": False, "message": "Failed to load selected image(s)"}

    node_result = create_projection_setup(
        material=material,
        empty_obj=empty_obj,
        image=image,
        mode=mode,
        filepaths=filepaths,
    )
    tex_node = node_result.get("image_texture")
    if tex_node is None:
        return {"ok": False, "message": "Failed to create Sticksy texture nodes"}

    if mode == MODE_ANIMATED:
        context.view_layer.update()
        add_offset_driver(tex_node, rig_obj, bone_name)
        context.view_layer.update()

    return {
        "ok": True,
        "message": f"New Sticksy layer created: {image.name}",
        "image": image,
        "image_name": image.name,
        **node_result,
    }