from __future__ import annotations

import bpy

from .collections import link_object_to_collection


def create_mapping_empty(context, name: str, world_location, collection) -> bpy.types.Object:
    empty_obj = bpy.data.objects.new(name, None)
    empty_obj.location = world_location
    apply_empty_defaults(empty_obj)
    link_object_to_collection(empty_obj, collection)
    return empty_obj


def get_empty_by_name(name: str) -> bpy.types.Object | None:
    obj = bpy.data.objects.get(name)
    if obj and obj.type == 'EMPTY':
        return obj
    return None


def apply_empty_defaults(empty_obj: bpy.types.Object) -> None:
    empty_obj.empty_display_type = 'PLAIN_AXES'
    empty_obj.empty_display_size = 0.25
    empty_obj.hide_select = True
    empty_obj.hide_render = True
    empty_obj.hide_viewport = True