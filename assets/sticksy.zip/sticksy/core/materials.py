import bpy


def get_material_by_name(name: str):
    if not name:
        return None
    return bpy.data.materials.get(name)



def validate_material(material) -> tuple[bool, str]:
    if material is None:
        return False, "No target material selected"
    if not isinstance(material, bpy.types.Material):
        return False, "Invalid target material"
    return True, ""



def material_uses_nodes(material: bpy.types.Material) -> bool:
    return bool(material and material.use_nodes and material.node_tree)
