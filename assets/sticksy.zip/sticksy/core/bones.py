from __future__ import annotations

from ..constants import (
    DEFAULT_FRAME_VALUE,
    MODE_SINGLE,
    PROP_CONTROLLER,
    PROP_EMPTY,
    PROP_FRAME,
    PROP_LABEL,
    PROP_MATERIAL,
    PROP_MODE,
)


def mark_as_controller(pbone) -> None:
    pbone[PROP_CONTROLLER] = True


def is_controller_bone(pbone) -> bool:
    return bool(pbone.get(PROP_CONTROLLER, False))


def configure_frame_property_ui(pbone, max_value: int = 0) -> None:
    max_value = max(0, int(max_value))
    ui = pbone.id_properties_ui(PROP_FRAME)
    ui.update(
        default=int(DEFAULT_FRAME_VALUE),
        min=0,
        max=max_value,
        soft_min=0,
        soft_max=max_value,
        description="Persistent Sticksy animation frame control",
    )


def enable_frame_library_override(pbone) -> bool:
    try:
        pbone.property_overridable_library_set(f'["{PROP_FRAME}"]', True)
        return True
    except Exception:
        return False


def init_controller_properties(
    pbone,
    label: str,
    mode: str,
    material_name: str,
    empty_name: str,
) -> None:
    pbone[PROP_CONTROLLER] = True
    pbone[PROP_LABEL] = label
    pbone[PROP_MODE] = mode or MODE_SINGLE
    pbone[PROP_MATERIAL] = material_name or ""
    pbone[PROP_EMPTY] = empty_name or ""
    pbone[PROP_FRAME] = int(DEFAULT_FRAME_VALUE)

    ui = pbone.id_properties_ui(PROP_LABEL)
    ui.update(description="Sticksy beauty name shown in the Manager")

    ui = pbone.id_properties_ui(PROP_MODE)
    ui.update(description="Sticksy controller mode: SINGLE or ANIMATED")

    ui = pbone.id_properties_ui(PROP_MATERIAL)
    ui.update(description="Material name where the original Sticksy texture was created")

    ui = pbone.id_properties_ui(PROP_EMPTY)
    ui.update(description="Mapping Empty name used by this Sticksy controller")

    configure_frame_property_ui(pbone, max_value=0)
    enable_frame_library_override(pbone)


def force_pose_bone_refresh(context, rig_obj, bone_name: str) -> bool:
    """Force Blender to reevaluate a freshly created technical pose bone.

    This is intentionally a localized hack for newly created Sticksy bones.
    It nudges the pose bone a small amount and restores it immediately.
    """
    if context is None or rig_obj is None or rig_obj.type != 'ARMATURE':
        return False

    if rig_obj.pose is None:
        return False

    pbone = rig_obj.pose.bones.get(bone_name)
    if pbone is None:
        return False

    try:
        original_location = pbone.location.copy()

        context.view_layer.update()

        nudged_location = original_location.copy()
        nudged_location.x += 0.1
        pbone.location = nudged_location
        context.view_layer.update()

        pbone.location = original_location
        context.view_layer.update()

        return True
    except Exception:
        return False


def get_label(pbone) -> str:
    return str(pbone.get(PROP_LABEL, ""))


def set_label(pbone, value: str) -> None:
    pbone[PROP_LABEL] = value


def get_mode(pbone) -> str:
    return str(pbone.get(PROP_MODE, MODE_SINGLE))


def get_frame_value(pbone) -> int:
    return int(pbone.get(PROP_FRAME, DEFAULT_FRAME_VALUE))


def set_frame_value(pbone, value: int) -> None:
    pbone[PROP_FRAME] = int(value)


def get_material_name(pbone) -> str:
    return str(pbone.get(PROP_MATERIAL, ""))


def get_empty_name(pbone) -> str:
    return str(pbone.get(PROP_EMPTY, ""))