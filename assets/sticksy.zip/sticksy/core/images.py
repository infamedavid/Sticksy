from __future__ import annotations

from pathlib import Path
import bpy

from ..constants import MODE_ANIMATED, MODE_SINGLE



def build_filepaths(directory: str, files) -> list[str]:
    directory = directory or ""
    return [str(Path(directory) / f.name) for f in files]



def sort_sequence_paths(filepaths: list[str]) -> list[str]:
    return sorted(filepaths)



def _normalized_path(filepath: str) -> str:
    return str(Path(filepath).expanduser().resolve())



def _find_loaded_image_by_path(filepath: str):
    normalized = _normalized_path(filepath)
    for image in bpy.data.images:
        try:
            if _normalized_path(bpy.path.abspath(image.filepath, library=image.library)) == normalized:
                return image
        except Exception:
            continue
    return None



def load_single_image(filepath: str):
    filepath = _normalized_path(filepath)
    existing = _find_loaded_image_by_path(filepath)
    if existing is not None:
        return existing
    return bpy.data.images.load(filepath, check_existing=True)



def load_image_sequence(filepaths: list[str]):
    sorted_paths = sort_sequence_paths(filepaths)
    if not sorted_paths:
        return None

    first_path = _normalized_path(sorted_paths[0])
    image = _find_loaded_image_by_path(first_path)
    if image is None:
        image = bpy.data.images.load(first_path, check_existing=True)

    image.source = 'SEQUENCE'
    image.filepath = first_path
    if hasattr(image, "filepath_raw"):
        image.filepath_raw = first_path
    return image



def validate_file_selection(filepaths: list[str], mode: str) -> tuple[bool, str]:
    if not filepaths:
        return False, "No files selected"
    if mode == MODE_SINGLE and len(filepaths) != 1:
        return False, "Single mode expects exactly one image"
    if mode == MODE_ANIMATED and len(filepaths) < 1:
        return False, "Animated mode expects one or more images"
    return True, ""



def count_frames(filepaths: list[str]) -> int:
    return len(filepaths)
