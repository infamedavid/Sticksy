from dataclasses import dataclass

from .bones import (
    get_empty_name,
    get_frame_value,
    get_label,
    get_material_name,
    get_mode,
    is_controller_bone,
)
from .rig import find_system_rig


@dataclass
class ControllerEntry:
    armature_name: str
    bone_name: str
    label: str
    mode: str
    material_name: str
    empty_name: str
    frame_value: int


def iter_system_rigs(scene):
    """Yield system armatures found in the scene.

    MVP rule: identify them by naming convention.
    """
    rig_obj = find_system_rig(scene)
    if rig_obj:
        yield rig_obj


def iter_controller_pose_bones(rig_obj):
    if rig_obj is None or rig_obj.type != 'ARMATURE' or rig_obj.pose is None:
        return
    for pbone in rig_obj.pose.bones:
        if is_controller_bone(pbone):
            yield pbone


def build_controller_entry(rig_obj, pbone) -> ControllerEntry:
    return ControllerEntry(
        armature_name=rig_obj.name,
        bone_name=pbone.name,
        label=get_label(pbone),
        mode=get_mode(pbone),
        material_name=get_material_name(pbone),
        empty_name=get_empty_name(pbone),
        frame_value=get_frame_value(pbone),
    )


def scan_scene_controllers(scene) -> list[ControllerEntry]:
    entries = []
    for rig_obj in iter_system_rigs(scene):
        for pbone in iter_controller_pose_bones(rig_obj):
            entries.append(build_controller_entry(rig_obj, pbone))
    return entries