from __future__ import annotations

import bpy

from .naming import make_system_collection_name



def ensure_system_collection(context) -> bpy.types.Collection:
    name = make_system_collection_name()
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        context.scene.collection.children.link(collection)
    elif context.scene.collection.children.get(collection.name) is None:
        context.scene.collection.children.link(collection)
    return collection



def link_object_to_collection(obj: bpy.types.Object, collection: bpy.types.Collection) -> None:
    if obj is None or collection is None:
        return
    if collection.objects.get(obj.name) is None:
        collection.objects.link(obj)



def unlink_from_other_collections(obj: bpy.types.Object) -> None:
    """Optional cleanup if you want Sticksy objects to live only in its own collection."""
    return None
