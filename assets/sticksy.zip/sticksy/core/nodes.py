from __future__ import annotations

import bpy

from ..constants import MODE_ANIMATED, SAFE_IMAGE_USER_DURATION
from .images import count_frames


def ensure_node_tree(material: bpy.types.Material) -> bpy.types.NodeTree:
    material.use_nodes = True
    return material.node_tree


def create_texture_coordinate_node(node_tree, empty_obj):
    node = node_tree.nodes.new("ShaderNodeTexCoord")
    node.object = empty_obj
    node.label = "Sticksy Object"
    return node


def create_image_texture_node(node_tree, image, mode: str):
    node = node_tree.nodes.new("ShaderNodeTexImage")
    node.image = image
    node.label = "Sticksy Image"
    configure_image_texture_node(node, mode)
    return node


def configure_image_texture_node(tex_node, mode: str, frame_count: int | None = None) -> None:
    tex_node.projection = 'FLAT'
    tex_node.extension = 'CLIP'

    if mode == MODE_ANIMATED and tex_node.image is not None:
        tex_node.image.source = 'SEQUENCE'
        tex_node.image_user.frame_start = 1
        tex_node.image_user.frame_offset = 0
        tex_node.image_user.frame_duration = int(SAFE_IMAGE_USER_DURATION)
        tex_node.image_user.use_cyclic = True
        if hasattr(tex_node.image_user, "use_auto_refresh"):
            tex_node.image_user.use_auto_refresh = True


def place_new_nodes(node_tree, nodes: list) -> None:
    if not nodes:
        return

    existing = [node for node in node_tree.nodes if node not in nodes]
    start_x = max((node.location.x for node in existing), default=0.0) + 240.0
    start_y = min((node.location.y for node in existing), default=0.0)

    for index, node in enumerate(nodes):
        node.location = (start_x + index * 260.0, start_y)


def create_projection_setup(material, empty_obj, image, mode: str, filepaths: list[str] | None = None) -> dict:
    node_tree = ensure_node_tree(material)
    texcoord_node = create_texture_coordinate_node(node_tree, empty_obj)
    frame_count = count_frames(filepaths or []) if mode == MODE_ANIMATED else None
    image_node = create_image_texture_node(node_tree, image, mode)
    if mode == MODE_ANIMATED:
        configure_image_texture_node(image_node, mode, frame_count=frame_count)

    node_tree.links.new(texcoord_node.outputs['Object'], image_node.inputs['Vector'])
    place_new_nodes(node_tree, [texcoord_node, image_node])

    return {
        "texcoord": texcoord_node,
        "image_texture": image_node,
    }