from __future__ import annotations

import re

from ..constants import (
    BONE_PREFIX,
    DEFAULT_LABEL_ANIMATED,
    DEFAULT_LABEL_SINGLE,
    EMPTY_PREFIX,
    MODE_ANIMATED,
    SYSTEM_ARMATURE_NAME,
    SYSTEM_COLLECTION_NAME,
)


_BONE_RE = re.compile(rf"^{re.escape(BONE_PREFIX)}(\d+)$")
_EMPTY_RE = re.compile(rf"^{re.escape(EMPTY_PREFIX)}(\d+)$")


def make_system_armature_name() -> str:
    return SYSTEM_ARMATURE_NAME


def make_system_collection_name() -> str:
    return SYSTEM_COLLECTION_NAME


def _extract_index(name: str, pattern: re.Pattern[str]) -> int | None:
    match = pattern.match(name)
    if not match:
        return None
    return int(match.group(1))


def next_controller_index(rig_obj) -> int:
    """Return the next numeric index for a new Sticksy controller bone.

    The MVP only needs armature data-bones here. Touching pose-bones can fail on a
    freshly-created rig before Blender has built pose data, and it adds no value
    for index generation because the technical bone names already exist in
    rig_obj.data.bones.
    """
    highest = 0
    if rig_obj is None or rig_obj.type != 'ARMATURE' or rig_obj.data is None:
        return 1

    for bone in rig_obj.data.bones:
        index = _extract_index(bone.name, _BONE_RE)
        if index is not None:
            highest = max(highest, index)

    return highest + 1


def make_bone_name(index: int) -> str:
    return f"{BONE_PREFIX}{index:03d}"


def make_empty_name(index: int) -> str:
    return f"{EMPTY_PREFIX}{index:03d}"


def make_default_label(mode: str, index: int) -> str:
    base = DEFAULT_LABEL_ANIMATED if mode == MODE_ANIMATED else DEFAULT_LABEL_SINGLE
    return f"{base}_{index:03d}"