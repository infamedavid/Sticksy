from __future__ import annotations

import bpy
from mathutils import Vector

from .collections import link_object_to_collection
from .naming import make_system_armature_name


_BONE_LENGTH = 0.25
_BONE_VISUAL_OFFSET = Vector((0.5, 0.5, 0.0))


def _safe_mode_set(mode: str) -> None:
    try:
        bpy.ops.object.mode_set(mode=mode)
    except RuntimeError:
        pass


def _activate_object(obj: bpy.types.Object | None) -> None:
    view_layer = bpy.context.view_layer
    if obj is None:
        view_layer.objects.active = None
        return
    obj.select_set(True)
    view_layer.objects.active = obj


def _deselect_all_objects() -> None:
    for obj in bpy.context.selected_objects:
        obj.select_set(False)


def _capture_object_context() -> dict:
    active = bpy.context.view_layer.objects.active
    selected_names = [obj.name for obj in bpy.context.selected_objects]
    mode = bpy.context.mode
    return {
        "active_name": active.name if active else None,
        "selected_names": selected_names,
        "mode": mode,
    }


def _restore_object_context(state: dict) -> None:
    active_name = state.get("active_name")
    selected_names = state.get("selected_names", [])
    previous_mode = state.get("mode", "OBJECT")

    if bpy.context.mode != 'OBJECT':
        _safe_mode_set('OBJECT')

    _deselect_all_objects()

    active_obj = bpy.data.objects.get(active_name) if active_name else None
    for name in selected_names:
        obj = bpy.data.objects.get(name)
        if obj is not None:
            obj.select_set(True)

    if active_obj is not None:
        bpy.context.view_layer.objects.active = active_obj
        target_mode = previous_mode.split('_', 1)[0]
        if target_mode in {'OBJECT', 'EDIT', 'POSE'}:
            _safe_mode_set(target_mode)
    else:
        bpy.context.view_layer.objects.active = None


def find_system_rig(scene) -> bpy.types.Object | None:
    name = make_system_armature_name()
    obj = bpy.data.objects.get(name)
    if obj and obj.type == 'ARMATURE':
        return obj
    return None


def ensure_system_rig(context, collection) -> bpy.types.Object:
    rig_obj = find_system_rig(context.scene)
    if rig_obj:
        link_object_to_collection(rig_obj, collection)
        return rig_obj

    arm_data = bpy.data.armatures.new(make_system_armature_name())
    rig_obj = bpy.data.objects.new(make_system_armature_name(), arm_data)
    link_object_to_collection(rig_obj, collection)
    rig_obj.location = (0.0, 0.0, 0.0)
    return rig_obj


def create_controller_bone(context, rig_obj, world_location, bone_name) -> str:
    """Create a new edit bone at the given world location and return its name."""
    if rig_obj is None or rig_obj.type != 'ARMATURE':
        raise ValueError("Invalid Sticksy rig object")

    state = _capture_object_context()
    try:
        if bpy.context.mode != 'OBJECT':
            _safe_mode_set('OBJECT')
        _deselect_all_objects()
        _activate_object(rig_obj)
        _safe_mode_set('EDIT')

        arm_data = rig_obj.data
        edit_bones = arm_data.edit_bones
        edit_bone = edit_bones.new(bone_name)

        bone_world_location = Vector(world_location) + _BONE_VISUAL_OFFSET
        local_head = rig_obj.matrix_world.inverted() @ bone_world_location
        local_tail = local_head + Vector((0.0, 0.0, _BONE_LENGTH))
        if (local_tail - local_head).length <= 1e-6:
            local_tail = local_head + Vector((0.0, _BONE_LENGTH, 0.0))

        edit_bone.head = local_head
        edit_bone.tail = local_tail
        return edit_bone.name
    finally:
        _restore_object_context(state)


def get_pose_bone(rig_obj, bone_name) -> bpy.types.PoseBone | None:
    if rig_obj is None or rig_obj.type != 'ARMATURE':
        return None
    return rig_obj.pose.bones.get(bone_name)


def parent_object_to_bone(obj, rig_obj, bone_name) -> None:
    """Parent the given object to a pose bone while preserving world transform."""
    if obj is None or rig_obj is None or rig_obj.type != 'ARMATURE':
        raise ValueError("Invalid parenting data for Sticksy Empty")
    if rig_obj.pose.bones.get(bone_name) is None:
        raise ValueError(f"Pose bone not found: {bone_name}")

    world_matrix = obj.matrix_world.copy()
    obj.parent = rig_obj
    obj.parent_type = 'BONE'
    obj.parent_bone = bone_name
    obj.matrix_world = world_matrix