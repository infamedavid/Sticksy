from .bones import get_empty_name, get_material_name, is_controller_bone
from .empties import get_empty_by_name
from .images import validate_file_selection
from .materials import get_material_by_name, validate_material



def validate_create_request(material, mode: str, filepaths: list[str]) -> tuple[bool, str]:
    ok, message = validate_material(material)
    if not ok:
        return ok, message
    return validate_file_selection(filepaths, mode)



def validate_new_layer_request(pbone, material, empty_obj, filepaths: list[str] | None = None, mode: str | None = None) -> tuple[bool, str]:
    if pbone is None or not is_controller_bone(pbone):
        return False, "Invalid Sticksy controller bone"
    if material is None:
        return False, "Stored material was not found"
    if empty_obj is None:
        return False, "Stored Empty was not found"
    if filepaths is not None and mode is not None:
        ok, message = validate_file_selection(filepaths, mode)
        if not ok:
            return False, message
    return True, ""



def validate_controller_data(pbone) -> tuple[bool, str]:
    if pbone is None or not is_controller_bone(pbone):
        return False, "Invalid Sticksy controller bone"
    material_name = get_material_name(pbone)
    empty_name = get_empty_name(pbone)
    if not material_name:
        return False, "Controller has no stored material name"
    if not empty_name:
        return False, "Controller has no stored Empty name"
    if get_material_by_name(material_name) is None:
        return False, f"Material not found: {material_name}"
    if get_empty_by_name(empty_name) is None:
        return False, f"Empty not found: {empty_name}"
    return True, ""
