from __future__ import annotations

import json
from pathlib import Path

import bpy

from .collections import link_object_to_collection


_SHAPE_OBJECT_NAME = "STKSY_TextureShape"
_SHAPE_JSON_FILENAME = "texture_shape.json"


def _shape_json_path() -> Path:
    return Path(__file__).resolve().parent.parent / "assets" / _SHAPE_JSON_FILENAME


def _hide_shape_source_object(obj: bpy.types.Object) -> None:
    obj.hide_select = True
    obj.hide_render = True
    obj.hide_viewport = True
    try:
        obj.hide_set(True)
    except Exception:
        pass


def ensure_texture_shape(collection) -> bpy.types.Object | None:
    obj = bpy.data.objects.get(_SHAPE_OBJECT_NAME)
    if obj and obj.type == 'MESH':
        link_object_to_collection(obj, collection)
        _hide_shape_source_object(obj)
        return obj

    json_path = _shape_json_path()
    if not json_path.exists():
        print(f"[Sticksy] Custom shape JSON not found: {json_path}")
        return None

    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
        vertices = data.get("vertices", [])
        edges = data.get("edges", [])

        mesh = bpy.data.meshes.new(_SHAPE_OBJECT_NAME)
        mesh.from_pydata(vertices, edges, [])
        mesh.update()

        obj = bpy.data.objects.new(_SHAPE_OBJECT_NAME, mesh)
        obj.display_type = 'WIRE'

        link_object_to_collection(obj, collection)
        _hide_shape_source_object(obj)
        return obj

    except Exception as exc:
        print(f"[Sticksy] Failed to build custom shape from JSON: {exc}")
        return None


def assign_texture_shape(pbone, shape_obj) -> None:
    if pbone is None or shape_obj is None:
        return

    pbone.custom_shape = shape_obj
    pbone.use_custom_shape_bone_size = True