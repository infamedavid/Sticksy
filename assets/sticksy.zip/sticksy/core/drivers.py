from __future__ import annotations

from ..constants import PROP_FRAME


def build_driver_expression() -> str:
    return "1+(frame*-1)+var"


def add_offset_driver(tex_node, rig_obj, bone_name: str):
    """Create a natural driver pointing directly to the pose-bone ID property.

    Target path:
        pose.bones["BONE_NAME"]["stksy_frame"]
    """
    if tex_node is None or rig_obj is None or rig_obj.type != 'ARMATURE':
        return None

    image_user = getattr(tex_node, "image_user", None)
    if image_user is None:
        return None

    if rig_obj.pose is None:
        return None

    pbone = rig_obj.pose.bones.get(bone_name)
    if pbone is None:
        return None

    data_path = pbone.path_from_id(f'["{PROP_FRAME}"]')

    clear_driver_if_needed(image_user, "frame_offset")

    fcurve = image_user.driver_add("frame_offset")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = build_driver_expression()

    var = driver.variables.new()
    var.name = "var"
    var.type = 'SINGLE_PROP'

    target = var.targets[0]
    target.id_type = 'OBJECT'
    target.id = rig_obj
    target.data_path = data_path

    return fcurve


def clear_driver_if_needed(id_block, data_path: str) -> None:
    try:
        id_block.driver_remove(data_path)
    except (TypeError, RuntimeError, ValueError, AttributeError):
        pass