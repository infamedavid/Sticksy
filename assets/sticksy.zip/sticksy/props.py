import bpy
from bpy.props import EnumProperty, PointerProperty, StringProperty

from .constants import MODE_ANIMATED, MODE_SINGLE


class STKSY_PG_scene_settings(bpy.types.PropertyGroup):
    target_material: PointerProperty(
        name="Material",
        type=bpy.types.Material,
        description="Material where Sticksy will create the image texture nodes",
    )

    create_mode: EnumProperty(
        name="Mode",
        items=[
            (MODE_SINGLE, "Single", "Create a single image texture setup"),
            (MODE_ANIMATED, "Animated", "Create an animated image-sequence setup"),
        ],
        default=MODE_SINGLE,
    )

    default_label: StringProperty(
        name="Label",
        description="Optional beauty name for the controller",
        default="",
    )
