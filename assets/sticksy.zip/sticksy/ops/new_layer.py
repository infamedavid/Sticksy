import bpy
from bpy.props import CollectionProperty, StringProperty
from bpy.types import Operator, OperatorFileListElement

from ..core.images import build_filepaths
from ..services.new_layer import create_new_layer


class STKSY_OT_new_layer(Operator):
    bl_idname = "sticksy.new_layer"
    bl_label = "New Layer"
    bl_description = "Create a new texture layer using an existing Sticksy controller"
    bl_options = {'REGISTER', 'UNDO'}

    armature_name: StringProperty()
    bone_name: StringProperty()
    directory: StringProperty(subtype='DIR_PATH')
    files: CollectionProperty(type=OperatorFileListElement)
    filter_glob: StringProperty(default="*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.exr;*.bmp", options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepaths = build_filepaths(self.directory, self.files)
        result = create_new_layer(
            context=context,
            armature_name=self.armature_name,
            bone_name=self.bone_name,
            filepaths=filepaths,
        )
        if not result.get("ok"):
            self.report({'WARNING'}, result.get("message", "New Layer failed"))
            return {'CANCELLED'}
        return {'FINISHED'}
