import bpy
from bpy.props import CollectionProperty, StringProperty
from bpy.types import Operator, OperatorFileListElement

from ..core.images import build_filepaths
from ..services.create_setup import create_setup


class STKSY_OT_create_setup(Operator):
    bl_idname = "sticksy.create_setup"
    bl_label = "Create"
    bl_description = "Create a new Sticksy setup"
    bl_options = {'REGISTER', 'UNDO'}

    directory: StringProperty(subtype='DIR_PATH')
    files: CollectionProperty(type=OperatorFileListElement)
    filter_glob: StringProperty(default="*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.exr;*.bmp", options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        settings = context.scene.sticksy
        filepaths = build_filepaths(self.directory, self.files)
        result = create_setup(
            context=context,
            material=settings.target_material,
            mode=settings.create_mode,
            filepaths=filepaths,
            label=settings.default_label or None,
        )
        if not result.get("ok"):
            self.report({'WARNING'}, result.get("message", "Create failed"))
            return {'CANCELLED'}
        if result.get("message"):
            self.report({'INFO'}, result["message"])
        return {'FINISHED'}
