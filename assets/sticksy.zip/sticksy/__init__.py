bl_info = {
    "name": "Sticksy",
    "author": "OpenAI + David",
    "version": (0, 2, 4),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Sticksy",
    "description": "Create mapped texture controllers using Empty + Armature + Bone",
    "category": "Material",
}

from .registration import register as register_addon
from .registration import unregister as unregister_addon


def register():
    register_addon()


def unregister():
    unregister_addon()